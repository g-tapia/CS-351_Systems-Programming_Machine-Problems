/******************************************************************************
 * 
 * Malloc lab header
 * 
 * Author: George Tapia
 * Email:  gtapia@iit.edu
 * AID:    A20450857
 * Date:   12/1/2021
 * 
 * By signing above, I pledge on my honor that I neither gave nor received any
 * unauthorized assistance on the code contained in this repository.
 * 
 *****************************************************************************/



#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "mm.h"
#include "memlib.h"

#define ALIGNMENT 8
#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7)

#define NUM_SIZE_CLASSES 11
size_t *size_classes; // 32, 64, ..., 16384, 32768, -1
#define SIZE_CLASS_START 5

typedef struct block block_t;
struct block {
  size_t size;
  block_t *next, *prev;
};

#define FREE_BIT 1ULL
#define GET_SIZE(size) ((size) & ~FREE_BIT)
#define GET_FREE(size) ((size) & FREE_BIT)

#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))
#define BLOCK_T_SIZE (ALIGN(sizeof(block_t)))
#define MIN_BLOCK_SIZE 32

#define DEBUGF(...) {}
#ifndef NDEBUG
// #undef DEBUGF
// #define DEBUGF(...) fprintf(stderr, __VA_ARGS__)
#endif

// 4-6 works about the same
#define SPLIT_INDEX 1

block_t *roots;
void *start_of_heap;
void *end_of_heap;

void print_full(void) {
  for (int i = 0; i < NUM_SIZE_CLASSES; ++i) {
    block_t *block = roots[i].next;
    printf("root %d, size class %ld\n", i, size_classes[i]);
    while (block != &roots[i]) {
      size_t *footer = (void *)block + GET_SIZE(block->size) - SIZE_T_SIZE;
      printf("  block %p, size %ld, footer size %ld\n", block, block->size, *footer);
      block = block->next;
    }
  }
}

void print_roots(void) {
  return;
  for (int i = 0; i < NUM_SIZE_CLASSES; ++i) {
    block_t *block = roots[i].next;
    int j = 0;
    while (block != &roots[i]) {
      ++j;
      block = block->next;
    }
    printf("root %d, size class %ld, %d entries\n", i, size_classes[i], j);
    if (i == NUM_SIZE_CLASSES - 1 && j > 0)
      print_full();
  }
}

int mm_init(void) {
  assert(BLOCK_T_SIZE == 24);
  size_classes = mem_sbrk(sizeof(size_t *) * NUM_SIZE_CLASSES);
  if (size_classes == (void *)-1)
    return -1;
  for (int i = 0; i < NUM_SIZE_CLASSES-1; ++i)
    size_classes[i] = 1 << (i+SIZE_CLASS_START);
  size_classes[NUM_SIZE_CLASSES-1] = -1;
  roots = mem_sbrk(BLOCK_T_SIZE * NUM_SIZE_CLASSES);
  if (roots == (void *)-1)
    return -1;
  start_of_heap = end_of_heap = (void *)roots + BLOCK_T_SIZE * NUM_SIZE_CLASSES;
  DEBUGF("start of heap %p, end of heap %p\n", start_of_heap, end_of_heap);
  for (int i = 0; i < NUM_SIZE_CLASSES; ++i) {
    roots[i].size = 0;
    roots[i].next = roots[i].prev = &roots[i];
  }
  return 0;
}

void remove_from_list(block_t *block) {
  DEBUGF("removing block of size %ld from list at %p\n", block->size, block);
  block->next->prev = block->prev;
  block->prev->next = block->next;
}

// c.f. <https://stackoverflow.com/a/466278/2769043> / <https://graphics.stanford.edu/~seander/bithacks.html#RoundUpPowerOf2>
size_t upper_power_of_two(size_t v) {
  v--;
  v |= v >> 1;
  v |= v >> 2;
  v |= v >> 4;
  v |= v >> 8;
  v |= v >> 16;
  v++;
  return v;
}
//-------------------------------------------------------------------------------
// c.f. <https://graphics.stanford.edu/~seander/bithacks.html#IntegerLogDeBruijn>
uint32_t log_of_two(uint32_t v) {
  static const int MultiplyDeBruijnBitPosition[32] = {
    0, 9, 1, 10, 13, 21, 2, 29, 11, 14, 16, 18, 22, 25, 3, 30,
    8, 12, 20, 28, 15, 17, 24, 7, 19, 27, 23, 6, 26, 5, 4, 31
  };

  v |= v >> 1;
  v |= v >> 2;
  v |= v >> 4;
  v |= v >> 8;
  v |= v >> 16;
//-------------------------------------------------------------------------------
  return MultiplyDeBruijnBitPosition[(uint32_t)(v * 0x07C4ACDDU) >> 27];
}

int size_to_class(size_t size) {
  int result = log_of_two(size) - SIZE_CLASS_START;
  if (result < NUM_SIZE_CLASSES)
    return result;
  return NUM_SIZE_CLASSES-1;
}

block_t *find_fit(size_t size) {
  for (int i = size_to_class(size); i < NUM_SIZE_CLASSES; ++i) {
    block_t *root = &roots[i];
    block_t *block = root->next;
    // assert(size >= size_classes[i]);
    if (block == root) {
      if (i <= SPLIT_INDEX)
        break;
      continue;
    }
    size_t min = -1;
    block_t *best = NULL;
    int k = 0;
    while (block != root && k < 10) {
      if (block->size >= size && block->size < min) {
        min = block->size;
        best = block;
      }
      block = block->next;
      ++k;
    }
    if (best != NULL) {
      remove_from_list(best);
      return best;
    }
  }
  return NULL;
}

size_t minimum_size(size_t request_size) {
  size_t size = ALIGN(request_size + 2 * SIZE_T_SIZE);
  if (size < MIN_BLOCK_SIZE)
    return MIN_BLOCK_SIZE;
  return size;
}

size_t lower_size(size_t request_size) {
  return minimum_size(request_size);
}

void insert(block_t *block) {
  assert(!GET_FREE(block->size));

  size_t size = block->size;
  assert(size > 0);

  size_t *footer = (void *)block + size - SIZE_T_SIZE;
  assert(!GET_FREE(*footer));

  size_t *left_footer = (void *)block - SIZE_T_SIZE;
  if (block != start_of_heap && GET_FREE(*left_footer)) {
    assert(GET_SIZE(*left_footer) != 0);
    size_t left_size = GET_SIZE(*left_footer);
    block_t *left = (void *)block - left_size;
    DEBUGF("coalescing left block %p of size %ld into us at %p\n", left, left_size, block);
    remove_from_list(left);
    size += left_size;
    block = left;
  }

  block_t *right = (void *)block + GET_SIZE(block->size);
  if (right != end_of_heap && GET_FREE(right->size)) {
    assert(GET_SIZE(right->size) != 0);
    size_t right_size = GET_SIZE(right->size);
    DEBUGF("coalescing right block %p of size %ld into us at %p\n", right, right_size, block);
    remove_from_list(right);
    size += right_size;
  }

  // insert into correct list
  block_t *root = &roots[NUM_SIZE_CLASSES-1];
  int i = size_to_class(size);

  DEBUGF("inserting block of size %ld at %p ends at %p, size class %d\n", size, block, (void *)block + size, i);
  if ((void *)block + size > end_of_heap)
    assert(0);

  // if (i < NUM_SIZE_CLASSES-1)
  //   assert(size == size_classes[i]);
  root = &roots[i];

  // adjusted size will not necessarily be a power of two
  // if it is, we can insert it into the correct list
  // otherwise, we insert into the top free list instead

  footer = (void *)block + size - SIZE_T_SIZE;
  block->size = *footer = size | FREE_BIT;

  block->prev = root;
  block->next = root->next;
  root->next = root->next->prev = block;
}

block_t *split_block(block_t *block, size_t size) {
  // assert(!GET_FREE(block->size));
  size_t block_size = GET_SIZE(block->size);
  size_t diff = block_size - size;
  if (block->size > size && diff > MIN_BLOCK_SIZE) {
    DEBUGF("splitting block of size %ld into two to reach %ld\n", block->size, size);
    size_t *footer = (void *)block + size - SIZE_T_SIZE;
    block->size = *footer = size;
    block_t *split = (void *)block + size;
    size_t *split_footer = (void *)split + diff - SIZE_T_SIZE;
    split->size = *split_footer = diff;
    DEBUGF("split into %ld + %ld\n", block->size, split->size);
    insert(split);
  } else {
    block->size = block_size;
  }
  return block;
}

void *mm_malloc(size_t request_size) {
  size_t size = lower_size(request_size);
  assert(size >= request_size);
  block_t *block = find_fit(size);
  if (block == NULL) {
    if (!(size & (size - 1))) {
      int j = size_to_class(size);
      if (j <= SPLIT_INDEX) {
        #define MULTIPLIER 2
        DEBUGF("allocating %d more of size %ld\n", MULTIPLIER - 1, size);
        size_t new_size = size * (MULTIPLIER-1);
        void *rest = mem_sbrk(new_size);
        if (rest == (void *)-1)
          return NULL;
        block_t *root = &roots[j];
        block = rest;
        size_t *footer = (void *)block + new_size - SIZE_T_SIZE;
        block->size = *footer = new_size | FREE_BIT;

        DEBUGF("adding block %p of size %ld\n", block, new_size);
        block->prev = root;
        block->next = root->next;
        root->next = root->next->prev = block;
      }
    }
    block = mem_sbrk(size);
    if (block == (void *)-1)
      return NULL;
    block->size = size;
    DEBUGF("got new block of size %ld at %p, ending at %p\n", size, block, (void *)block + size);
    end_of_heap = (void *)block + size;
    DEBUGF("start of heap %p, end of heap %p\n", start_of_heap, end_of_heap);
  } else {
    DEBUGF("got existing block at %p, size %ld, ending at %p\n", block, size, (void *)block + block->size);
    block = split_block(block, size);
  }
  size_t block_size = block->size;
  block_size &= ~FREE_BIT;
  DEBUGF("block is now %p, size %ld\n", block, block_size);
  size_t *footer = (void *)block + block_size - SIZE_T_SIZE;
  block->size = *footer = block_size;
  void *result = (void *)block + SIZE_T_SIZE;
  if (result + request_size >= end_of_heap)
    assert(0);
  return result;
}

void mm_free(void *pointer) {
  block_t *block = pointer - SIZE_T_SIZE;
  size_t size = GET_SIZE(block->size);
  size_t *footer = (void *)block + size - SIZE_T_SIZE;
  DEBUGF("freeing %p, size %ld\n", block, size);
  *footer = size;
  insert(block);
}

void *mm_realloc(void *pointer, size_t request_size) {
  // implementation-defined
  if (request_size == 0) {
    mm_free(pointer);
    return NULL;
  }

  block_t *block = pointer - SIZE_T_SIZE;

  DEBUGF("realloc of pointer %p, block %p, to size %ld\n", pointer, block, request_size);

  size_t size = lower_size(request_size);
  assert(size >= request_size);
  size_t current = block->size;

  DEBUGF("current %ld, want %ld, got %ld, minimum was %ld\n", current, request_size, size, minimum_size(request_size));

  if (minimum_size(request_size) <= current) {
    DEBUGF("returning directly %p\n", pointer);
    return pointer;
  }

  if ((void *)block + current == end_of_heap) {
    size_t missing = size - current;
    void *end = mem_sbrk(missing);
    if (end == (void *)-1)
      return NULL;
    DEBUGF("reallocated new block of size %ld at %p, ending at %p\n", size, block, (void *)block + size);
    end_of_heap = (void *)block + size;
    DEBUGF("start of heap %p, end of heap %p\n", start_of_heap, end_of_heap);
    size_t *footer = end_of_heap - SIZE_T_SIZE;
    block->size = *footer = size;
    return pointer;
  }

  size_t *left_footer = (void *)block - SIZE_T_SIZE;
  if (block != start_of_heap && GET_FREE(*left_footer) && size + GET_SIZE(*left_footer) >= request_size) {
    assert(GET_SIZE(*left_footer) != 0);
    size_t left_size = GET_SIZE(*left_footer);
    block_t *left = (void *)block - left_size;
    DEBUGF("coalescing left block %p of size %ld into us at %p, sized %ld\n", left, left_size, block, current);
    remove_from_list(left);
    size = current + left_size;

    size_t *footer = (void *) left + size - SIZE_T_SIZE;
    left->size = *footer = size;
    DEBUGF("copying from %p to %p, length %ld\n", pointer, (void *)left + SIZE_T_SIZE, current);
    return memmove((void *)left + SIZE_T_SIZE, pointer, current);
  }

  block_t *right = (void *)block + current;
  if (right != end_of_heap && GET_FREE(right->size) && size + GET_SIZE(right->size) >= request_size) {
    assert(GET_SIZE(right->size) != 0);
    size_t right_size = GET_SIZE(right->size);
    DEBUGF("coalescing right block %p of size %ld into us at %p, sized %ld\n", right, right_size, block, current);
    remove_from_list(right);
    size = current + right_size;

    size_t *footer = (void *) block + size - SIZE_T_SIZE;
    block->size = *footer = size;
    return pointer;
  }

  void *result = mm_malloc(request_size);
  DEBUGF("had to malloc %ld, got %p\n", request_size, result);
  if (result == NULL)
    return NULL;
  DEBUGF("copying from %p to %p, %ld bytes\n", pointer, result, current);
  memcpy(result, pointer, current);
  mm_free(pointer);
  return result;
}
