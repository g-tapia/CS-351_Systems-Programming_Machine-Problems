/******************************************************************************
 *
 * Cache lab header
 *
 * Author: Charlie S. Student
 * Email:  csstudent@iit.edu
 * AID:    A12345678
 * Date:   XX/XX/XX
 *
 * By signing above, I pledge on my honor that I neither gave nor received any
 * unauthorized assistance on the code contained in this repository.
 *
 *****************************************************************************/

#include "cachelab.h"

int main()
{
    printSummary(0, 0, 0);
    return 0;
}
