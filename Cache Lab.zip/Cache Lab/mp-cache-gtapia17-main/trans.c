/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);
void trans(int M, int N, int A[N][M], int B[M][N]);

void transposeUneven(int M, int N, int A[N][M], int B[M][N])
{
  int blocksize = 16;
  int col,row,rowIndex,columnIndex,dIndex;
  int dvalue = 0;

  //looping through each individual column and row
  for(col = 0; col < N; col += blocksize){
    for(row = 0; row < M; row += blocksize){
      //rowIndex and columnIndex will keep track of the row and column indices as we loop through each block
	    for(rowIndex = row; rowIndex < (row + blocksize); rowIndex++){
	      for(columnIndex = col; columnIndex < (col + blocksize); columnIndex++){
      //When the row and column doesn't match, transpose
		  if(rowIndex!=columnIndex) {
          B[columnIndex][rowIndex] = A[rowIndex][columnIndex];
          }
		  else
		    { //assigning the rowIndex to a place holder variable dIndex, this allows us to preserve a catch miss during each execution. Of course, this is only when the rowIndex and columnIndex match up.
          dvalue = A[rowIndex][columnIndex];
		      dIndex = rowIndex;
		    }
		  }//when row and column are equivalent, we assign it our placeholder value
	  if(row == col)
		{B[dIndex][dIndex] = dvalue;}
	  }
	 }
  }
}

void transpose(int size, int M, int N, int A[N][M], int B[M][N])
{
  int blocksize,col,row,rowIndex,columnIndex,dIndex;
  int dvalue = 0;
  if(size == 32)
    {blocksize = 8;}
  else//here to handle a size 64
    {blocksize = 4;}
  //looping through each individual column and row
  for(col = 0; col < N; col += blocksize){
    for(row = 0; row < M; row += blocksize){
	    for(rowIndex = row; rowIndex < (row + blocksize); rowIndex++){
	      for(columnIndex = col; columnIndex < (col + blocksize); columnIndex++){
		  if(rowIndex!=columnIndex) {
          B[columnIndex][rowIndex] = A[rowIndex][columnIndex];
          }
		  else
		    { 
          dvalue = A[rowIndex][columnIndex];
		      dIndex = rowIndex;
		    }
		  }
    //
	  if(row == col)
		{B[dIndex][dIndex] = dvalue;}
	  }
	 }
  }
}
/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
  int i, j;

  int block_size;
  switch (M) {
  case 64:
    transpose(64,M,N,A,B);
    break;
  case 32:
    transpose(32,M,N,A,B);
    break;
  case 61:
    transposeUneven(M,N,A,B);
    break;
  default:
    trans(M, N, A, B);
    return;
  }
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            B[j][i] = A[i][j];
        }
    }    
}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    registerTransFunction(trans, trans_desc); 
}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

