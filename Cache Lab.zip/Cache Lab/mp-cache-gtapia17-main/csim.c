/******************************************************************************
 *
 * Cache lab header
 *
 * Author: George Tapia Student
 * Email:  gtapia@hawk.iit.edu
 * AID:    A20450857
 * Date:   11/8/2021
 *
 * By signing above, I pledge on my honor that I neither gave nor received any
 * unauthorized assistance on the code contained in this repository.
 *
 *****************************************************************************/

#include <getopt.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "cachelab.h"

typedef struct {
  uint64_t tag;
  char valid;
  int last_used;
} cache_line_t;

void fprint_cache(FILE *stream, cache_line_t *cache, int nsets, int nlines) {
  fprintf(stream, "---\n");
  for (int i = 0; i < nsets; ++i) {
    if (i != 0) {
      fprintf(stream, "\n");
    }
    fprintf(stream, "cache set %d\n", i);
    for (int j = 0; j < nlines; ++j) {
      int offset = i * nlines + j;
      cache_line_t *current = cache + offset;
      fprintf(stream, "%d: cache line %p, valid %d, tag %lx, last used %d\n", offset, current, current->valid, current->tag, current->last_used);
    }
  }
  fprintf(stream, "---\n");
}

int main(int argc, char *argv[]) {
  int verbose = 0;
  int set_index_bits = 0;
  int associativity = 0;
  int block_bits = 0;
  char *trace_file = NULL;

  opterr = 0;

  int c;
  while ((c = getopt (argc, argv, "hvs:E:b:t:")) != -1)
    switch (c) {
    case 'h':
      printf("usage: ./csim [-hv] -s <s> -E <E> -b <b> -t <tracefile>\n\
\n\
-h                Optional help flag that prints usage info\n\
-v                Optional verbose flag that displays trace info\n\
-s <s>            Number of set index bits (S = 2^s is the number of sets)\n\
-E <E>            Associativity (number of lines per set)\n\
-b <b>            Number of block bits (B = 2^b is the block size)\n\
-t <tracefile>    Name of the `valgrind` trace to replay\n");
      return EXIT_SUCCESS;
    case 'v':
      verbose = 1;
      break;
    case 's':
      set_index_bits = atoi(optarg);
      break;
    case 'E':
      associativity = atoi(optarg);
      break;
    case 'b':
      block_bits = atoi(optarg);
      break;
    case 't':
      trace_file = strdup(optarg);
      break;
    case '?':
      if (optopt == 's' || optopt == 'E' || optopt == 'b' || optopt == 't')
        fprintf(stderr, "Option -%c requires an argument.\n", optopt);
      else
        fprintf(stderr, "Unknown option character '%c'.\n", optopt);
      return EXIT_FAILURE;
    default:
      fprintf(stderr, "Unexpected 'getopt' return value '%c'.\n", optopt);
      return EXIT_FAILURE;
    }

  if (set_index_bits <= 0) {
    fprintf(stderr, "number of set index bits '-s <s>' needs to be provided (> 0)\n");
    return EXIT_FAILURE;
  }

  if (associativity <= 0) {
    fprintf(stderr, "associativity '-E <E>' needs to be provided (> 0)\n");
    return EXIT_FAILURE;
  }

  if (block_bits <= 0) {
    fprintf(stderr, "number of block bits '-b <b>' needs to be provided (> 0)\n");
    return EXIT_FAILURE;
  }

  if (trace_file == NULL) {
    fprintf(stderr, "trace file '-t <tracefile>' needs to be provided\n");
    return 1;
  }

  FILE *trace = fopen(trace_file, "r");
  if (trace == NULL) {
    perror("couldn't open trace file");
    return 1;
  }

  int nsets = 1 << set_index_bits;
  int nlines = associativity;
  int nblocks = 1 << block_bits;

  int tag_shift = set_index_bits + block_bits;
  int set_shift = block_bits;

  uint64_t tag_mask = ((1 << (64 - tag_shift)) - 1) << tag_shift;
  uint64_t set_mask = ((1 << set_index_bits) - 1) << set_shift;
  uint64_t offset_mask = (1 << block_bits) - 1;

  size_t total = nsets * nlines;

  if (verbose) {
    fprintf(stderr, "%d set bits, %d lines, %d block bits\n", set_index_bits, associativity, block_bits);
    fprintf(stderr, "%d sets, %d lines per set, %d bytes per block, %lu cache lines, %lu bytes cache size\n", nsets, nlines, nblocks, total, total * nblocks);
    fprintf(stderr, "%lx tag mask, %d tag shift\n", tag_mask, tag_shift);
    fprintf(stderr, "%lx set mask, %d set shift\n", set_mask, set_shift);
    fprintf(stderr, "%lx block mask\n", offset_mask);
  }

  int hits = 0;
  int misses = 0;
  int evictions = 0;

  cache_line_t *cache = calloc(total, sizeof(cache_line_t));

  char *line = NULL;
  size_t length = 0;
  ssize_t n;
  int ip = 0;
  while ((n = getline(&line, &length, trace)) != -1) {
    if (n == 0 || line[0] == 'I') {
      continue;
    }

    char kind;
    uint64_t address;
    sscanf(line, " %c %lx", &kind, &address);

    uint64_t tag = (address & tag_mask) >> tag_shift;
    uint64_t set = (address & set_mask) >> set_shift;
    uint64_t offset = address & offset_mask;

    if (verbose) {
      fprint_cache(stderr, cache, nsets, nlines);
      fprintf(stderr, "%d: kind %c, address %lx; tag %lx, set %lx, block offset %lx\n", ip, kind, address, tag, set, offset);
    }

    cache_line_t *lines = cache + set * nlines;

    cache_line_t *current;
    int found = 0;
    for (int i = 0; i < nlines; i++) {
      current = lines + i;

      if (current->tag == tag) {
        found = 1;
        break;
      }
    }

    switch (kind) {
    case 'L':
    case 'M':
      if (found) {
        int miss = !current->valid;
        current->last_used = ip;
        if (miss) {
          if (verbose) {
            fprintf(stderr, "read miss, no eviction\n");
          }
          ++misses;
          current->valid = 1;
        } else {
          if (verbose) {
            fprintf(stderr, "read hit\n");
          }
          ++hits;
        }
      } else {
        cache_line_t *lru = NULL;
        for (int i = 0; i < nlines; i++) {
          current = lines + i;

          if (!current->valid && (lru == NULL || current->last_used < lru->last_used)) {
            lru = current;
          }
        }

        if (lru == NULL) {
          for (int i = 0; i < nlines; i++) {
            current = lines + i;

            if (lru == NULL || current->last_used < lru->last_used) {
              lru = current;
            }
          }
        }

        ++misses;
        if (lru->valid) {
          ++evictions;
          if (verbose) {
            fprintf(stderr, "read miss, eviction\n");
          }
        } else {
          if (verbose) {
            fprintf(stderr, "read miss, no eviction\n");
          }
        }

        lru->tag = tag;
        lru->valid = 1;
        lru->last_used = ip;

        // this allows us to fall through to the store case later
        found = 1;
        current = lru;
      }
      if (kind == 'L') {
        break;
      }
      // fall through in case of modify = load + store
    case 'S':
      if (found) {
        int miss = !current->valid;
        current->last_used = ip;
        if (miss) {
          if (verbose) {
            fprintf(stderr, "write miss, no eviction\n");
          }
          ++misses;
          current->valid = 1;
        } else {
          if (verbose) {
            fprintf(stderr, "write hit\n");
          }
          ++hits;
        }
      } else {
        cache_line_t *lru = NULL;
        for (int i = 0; i < nlines; i++) {
          current = lines + i;

          if (!current->valid && (lru == NULL || current->last_used < lru->last_used)) {
            lru = current;
          }
        }

        if (lru == NULL) {
          for (int i = 0; i < nlines; i++) {
            current = lines + i;

            if (lru == NULL || current->last_used < lru->last_used) {
              lru = current;
            }
          }
        }

        ++misses;
        if (lru->valid) {
          ++evictions;
          if (verbose) {
            fprintf(stderr, "write miss, eviction\n");
          }
        } else {
          if (verbose) {
            fprintf(stderr, "write miss, no eviction\n");
          }
        }

        lru->tag = tag;
        lru->valid = 1;
        lru->last_used = ip;
      }
      break;
    default:
      fprintf(stderr, "unexpected instruction %c\n", kind);
      goto cleanup;
    }

    ++ip;
  }

cleanup:
  free(line);
  (void) fclose(trace);

  printSummary(hits, misses, evictions);

  return EXIT_SUCCESS;
}
